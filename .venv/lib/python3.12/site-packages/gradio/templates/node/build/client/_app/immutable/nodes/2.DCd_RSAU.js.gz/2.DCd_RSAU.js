import { z, _ } from "../chunks/2.Dh-xFOZb.js";
export {
  z as component,
  _ as universal
};
